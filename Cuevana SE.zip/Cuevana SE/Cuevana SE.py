import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import numpy as np

from fuzzy_expert.variable import FuzzyVariable
from fuzzy_expert.rule import FuzzyRule
from fuzzy_expert.inference import DecompositionalInference

from tkinter import ttk
from tkinter import *

class Aplicacion:
    #Constructor
    def __init__(self, window):
        #Variables maquina de inferencia
        self.respuesta = ""
        self.state = 0
        self.preguntas = [
            "Quieres ver pelicula de duracion corta? (5-20 min)",
            "Quieres ver pelicula de duracion promedio? (21-24 min)",
            "Quieres ver pelicula de duracion intermedia (25-60 min)",
            "Quieres ver pelicula medianamente larga (60-90 min)",
            "Quieres ver peliculade larga (90-120 min)",
            "Quieres ver pelicula moderna? (2020-2022)",
            "Quieres ver pelicula recientemente moderna (2014-2019)",
            "Quieres ver pelicula de los 2010s (2009-2013)",
            "Quieres ver pelicula de inicios de siglo (2000-2008)",
            "Quieres ver peliculade los 90s (1989-1999)",

        ]
        self.vars_respuesta = []
        self.df = pd.read_csv(r"data\Top 50 Animation Movies and TV Shows.csv")

        # Initializations 
        self.wind = window
        self.wind.title('Expert System')
       # self.wind.geometry('400x400')
        self.wind.columnconfigure(0, weight=1)
        self.wind.rowconfigure(0, weight=1)


        # Creating a Frame Container 
        frame = LabelFrame(self.wind, text = 'Recomendador de peliculas/Series de animacion')
        frame.grid(row = 0, column = 0, pady = 20,padx=20)


      
        self.pregunta = Label(frame, text = '')
        self.pregunta.grid(row = 1, column = 0, pady = 10,padx=90)
        self.pregunta.grid_remove()


        ttk.Button(frame, text = 'Si', command = self.selec_si).grid(row=2,column=0,padx=90)
        ttk.Button(frame, text = 'Talvez si', command = self.selec_talvez_si).grid(row=3, column=0)
        ttk.Button(frame, text = 'No se', command = self.selec_no_se).grid(row=4, column=0)
        ttk.Button(frame, text = 'Casi no', command = self.selec_casi_no).grid(row=5, column=0)
        ttk.Button(frame, text = 'No', command = self.selec_no).grid(row=6, column=0)

        self.nextboton = ttk.Button(frame, text = 'Empezar Preguntas', command = self.nextbutton)
        self.nextboton.grid(row = 7, columnspan = 2,pady = 40)

        self.content = Label(frame, text = '')
        self.content.grid(row = 8, column = 0, pady = 10)
        self.content.grid_remove()

        #Varaibles de logica difusa
        self.variables_fecha = {
        "noventas": FuzzyVariable(
            universe_range=(1986,2025),
            terms={
                "si_noventas": ('trapmf', 1988,1989, 1999, 2000),
                "no_noventas":('trapmf', 1999,2000, 2022, 2023),
                #"dolmildiez": ('trapmf', 2010,2011, 2022, 2023),
            },
        ),
        "inicio_siglo": FuzzyVariable(
            universe_range=(1986,2025),
            terms={
                "si_inicio_siglo":('trapmf', 1999,2000, 2008, 2009),
                "no_inicio_siglo":[(1988,0.0),(1989,1.0),(1999,1.0),(2000,0.0),(2008,0.0),(2009,1.0),(2022,1.0),(2023,1.0)],
            },
        ),
        "dosmildiez": FuzzyVariable(
            universe_range=(1986,2025),
            terms={
                "si_dosmildiez": ('trapmf', 2008,2009, 2013, 2014),
                "no_dosmildiez": [(1988,0.0),(1989,1.0),(2008,1.0),(2009,0.0),(2013,0.0),(2014,1.0),(2022,1.0),(2023,1.0)],
            },
        ),
        "rel_reciente": FuzzyVariable(
            universe_range=(1986,2025),
            terms={
                "si_rel_reciente": ('trapmf', 2013,2014, 2019, 2020),
                "no_rel_reciente": [(1988,0.0),(1989,1.0),(2013,1.0),(2014,0.0),(2019,0.0),(2020,1.0),(2022,1.0),(2023,1.0)],
            },
        ),
        "reciente": FuzzyVariable(
            universe_range=(1986,2025),
            terms={
                "si_reciente": ('trapmf', 2019,2020, 2022, 2023),
                "no_reciente": ('trapmf', 1988,1989, 2019, 2020),
            },
        ),
        
        }
        self.variables_duracion = {
        "corto": FuzzyVariable(
            universe_range=(0,120),
            terms={
                "si_corto": ('trapmf', 4,5,20, 21),
                "no_corto":('trapmf', 20,21,120,121),
                #"dolmildiez": ('trapmf', 2010,2011, 2022, 2023),
            },
        ),
        "mediocorto": FuzzyVariable(
            universe_range=(0,120),
            terms={
                "si_mediocorto":('trapmf', 20,21,25,26),
                "no_mediocorto":[(4,0.0),(5,1.0),(20,1.0),(21,0.0),(35,0.0),(36,1.0),(120,1.0),(121,1.0)],
            },
        ),
        "mediano": FuzzyVariable(
            universe_range=(0,120),
            terms={
                "si_mediano": ('trapmf', 25,26, 60, 61),
                "no_mediano": [(4,0.0),(5,1.0),(35,1.0),(36,0.0),(60,0.0),(61,1.0),(120,1.0),(121,1.0)],
            },
        ),
        "mediolargo": FuzzyVariable(
            universe_range=(0,120),
            terms={
                "si_mediolargo": ('trapmf', 60,61, 90, 91),
                "no_mediolargo": [(4,0.0),(5,1.0),(60,1.0),(61,0.0),(90,0.0),(91,1.0),(120,1.0),(121,1.0)],
            },
        ),
        "largo": FuzzyVariable(
            universe_range=(0,120),
            terms={
                "si_largo": ('trapmf', 90,91,120,121),
                "no_largo": ('trapmf', 4,5, 90, 91),
            },
        ),
        
        
        }
        self.variables_intermedias = {
            "decision_minutos": FuzzyVariable(
                universe_range=(0, 10),
                terms={
                    "no": ('trapmf', 0,0.2,1.8, 2),
                    "casino":('trapmf', 2,2.2, 3.8, 4.0),
                    "nose": ('trapmf', 4.0,4.2, 5.8, 6.0),
                    "talvezsi": ('trapmf', 6.0,6.2, 7.8, 8.0),
                    "si": ('trapmf', 8.0,8.2, 9.8, 10.0),
                },
            ),
            
            "decision_fecha": FuzzyVariable(
                universe_range=(0, 10),
                terms={
                    "no": ('trapmf', 0,0.2,1.8, 2),
                    "casino":('trapmf', 2,2.2, 3.8, 4.0),
                    "nose": ('trapmf', 4.0,4.2, 5.8, 6.0),
                    "talvezsi": ('trapmf', 6.0,6.2, 7.8, 8.0),
                    "si": ('trapmf', 8.0,8.2, 9.8, 10.0),
                },
            ),
        }
        self.variable_global = {
            "decision": FuzzyVariable(
                universe_range=(0, 9),
                terms={
                    "no": ('trapmf', 0,0.2,0.8, 1),
                    "no_casino": ('trapmf', 1,1.2,1.8, 2),
                    "casino":('trapmf', 2,2.2, 2.8, 3.0),
                    "nose_casino":('trapmf', 3,3.2, 3.8, 4.0),
                    "nose": ('trapmf', 4.0,4.2, 4.8, 5.0),
                    "talvezsi_nose": ('trapmf', 5.0,5.2, 5.8, 6.0),
                    "talvezsi": ('trapmf', 6.0,6.2, 6.8, 7.0),
                    "talvezsi_si": ('trapmf', 7.0,7.2, 7.8, 8.0),
                    "si": ('trapmf', 8.0,8.2, 8.8, 9.0),

                        
                },
            ),
        }
        self.variables = self.variables_fecha | self.variables_duracion | self.variables_intermedias
        self.macro_variables = self.variables_intermedias | self.variable_global 

        self.macro_rules = [
            FuzzyRule(
                premise=[
                    ("decision_fecha", "si"),
                    ("AND", "decision_minutos", "si"),
                ],
                consequence=[("decision", "si")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "talvezsi"),#
                    ("AND", "decision_minutos", "si"),
                ],
                consequence=[("decision", "talvezsi_si")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "talvezsi"),
                    ("AND", "decision_minutos", "talvezsi"),
                ],
                consequence=[("decision", "talvezsi")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "nose"),
                    ("AND", "decision_minutos", "si"),
                ],
                consequence=[("decision", "talvezsi")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "nose"),#
                    ("AND", "decision_minutos", "talvezsi"),
                ],
                consequence=[("decision", "talvezsi_nose")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "nose"),
                    ("AND", "decision_minutos", "nose"),
                ],
                consequence=[("decision", "nose")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "casino"), #
                    ("AND", "decision_minutos", "nose"),
                ],
                consequence=[("decision", "nose_casino")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "casino"),
                    ("AND", "decision_minutos", "casino"),
                ],
                consequence=[("decision", "casino")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "no"),
                    ("AND", "decision_minutos", "nose"),
                ],
                consequence=[("decision", "casino")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "no"),#
                    ("AND", "decision_minutos", "casino"),
                ],
                consequence=[("decision", "no_casino")],
            ),
            FuzzyRule(
                premise=[
                    ("decision_fecha", "no"),
                    ("AND", "decision_minutos", "no"),
                ],
                consequence=[("decision", "no")],
            ),
        ]
        
    def selec_si(self):
        self.respuesta = "si"
    def selec_talvez_si(self):
        self.respuesta = "talvezsi"
    def selec_no_se(self):
        self.respuesta = "nose"
    def selec_casi_no(self):
        self.respuesta = "casino"
    def selec_no(self):
        self.respuesta = "no"
    
     
    def nextbutton(self):
        if self.state == 0:
            self.content.grid_remove()
            self.nextboton["text"]="Siguiente Pregunta"
            self.pregunta["text"]=self.preguntas[0]
            self.pregunta.grid()
        elif self.state < len(self.preguntas):
            self.pregunta["text"]=self.preguntas[self.state]
            self.vars_respuesta.append(self.respuesta)
            print("Entro a preguntas")
        elif self.state == len(self.preguntas):
            self.vars_respuesta.append(self.respuesta)
            self.pregunta["text"]="Las preguntas se acabaron"
            self.nextboton["text"]="Generar Recomendaciones"
            print("Entro a generar recomendaciones")
            print(self.vars_respuesta)
            
        
        if self.state > len(self.preguntas):
            resultado = self.motordeInferencias()
            publish = []
            probabilidad = 0.0
            if len(resultado["100"]) != 0:
                publish = resultado["100"]
                probabilidad = 95.0
            elif len(resultado["90"]) != 0:
                publish = resultado["90"]
                probabilidad = 90.0
            elif len(resultado["80"]) != 0:
                publish = resultado["80"]
                probabilidad = 80.0
            elif len(resultado["65"]) != 0:
                publish = resultado["65"]
                probabilidad = 65.0
         
            self.content["text"]="Primer Sentencia\nSegunda sentencia"
            testo_resultado = f"Estas son las recomendaciones de acuerdo a sus preferencias\ncon un factor de certeza del {probabilidad} porciento:\n\n"
            for element in publish:
                testo_resultado = testo_resultado + element + "\n"
            self.content["text"] = testo_resultado
            self.content.grid()
            self.pregunta.grid_remove()
            self.nextboton["text"]="Iniciar de nuevo"
            self.vars_respuesta = []
            self.state = 0
        else:
            self.state +=1

    def motordeInferencias(self):
        inputs_duracion = [
            ('corto',self.vars_respuesta[0]),
            ('mediocorto',self.vars_respuesta[1]),
            ('mediano',self.vars_respuesta[2]),
            ('mediolargo',self.vars_respuesta[3]),
            ('largo',self.vars_respuesta[4]),
            ]
        premisas_duracion = self.createRules(inputs_duracion,prefix="OR")
        inputs_fecha = [
            ('reciente',self.vars_respuesta[5]),
            ('rel_reciente',self.vars_respuesta[6]),
            ('dosmildiez',self.vars_respuesta[7]),
            ('inicio_siglo',self.vars_respuesta[8]),
            ('noventas',self.vars_respuesta[9]),
            ]
        prefix_list = {
            "si":"AND",
            "talvezsi":"AND",
            "nose":"AND",
            "casino":"OR",
            "no":"OR",
        }
        premisas_fechas = self.createRules(inputs_fecha,prefix=prefix_list)
        #Creacion de reglas
        rules_fechas = self.reglas(premisas_fechas,"decision_fecha")
        rules_minutos = self.reglas(premisas_duracion,"decision_minutos")
        self.rules = rules_fechas+ rules_minutos

        self.model = DecompositionalInference(
            and_operator="min",
            or_operator="max",
            implication_operator="Rc",
            composition_operator="max-min",
            production_link="max",
            defuzzification_operator="cog",
        )

        #Tratamiento de la data

        data_fechas = []
        for element in self.df.loc[:,"Year"]:
            dato = element.split("-")
            try:
                dato1 = "2022" if dato[1] == "" else dato[1]
                data_fechas.append([
                    (int(dato[0])-1,0.0),
                    (int(dato[0]),1.0),
                    (int(dato1),1.0),
                    (int(dato1)+1,0.0),
                    ])
            except IndexError:
                data_fechas.append([
                    (int(dato[0])-1,0.0),
                    (int(dato[0]),1.0),
                    (int(dato[0])+1,0.0),
                    ])

        cleanData = {
            "Year":data_fechas,
            "Minutes":self.df.loc[:,"Minutes"],
        }
        nameFrame = iter(self.df.loc[:,"Name"])
        res = self.segmentarPeliculas(cleanData,nameFrame)
        return res

    def segmentarPeliculas(self,data,Nameframe):
        segmentacion = {"100": [], "90": [],"80": [],"65":[],"50": [],"35":[],"25": [],"10":[],"0": [],}
        nombre = Nameframe #iter(dataframe.loc[:,"Name"])
        
        fecha_iter = data["Year"]
        mins_iter = data["Minutes"]

        for element in range(0,46): #tamaño fijo del dataset
            #Descomposion de la data
            
            fecha = fecha_iter[element]
            mins = int(mins_iter[element])
        
            #Parametros del modelo
            
            parametros_fecha = {
                "noventas":fecha,
                "inicio_siglo":fecha,
                "dosmildiez":fecha,
                "rel_reciente":fecha,
                "reciente":fecha,
            }
            parametros_mins = {
                "corto":mins,
                "mediocorto":mins,
                "mediano":mins,
                "mediolargo":mins,
                "largo":mins,
            }
            #Calculo del modelo
            sub_result = self.model(
                variables=self.variables,
                rules=self.rules,
                **parametros_fecha,
                **parametros_mins,
                )
            result = self.model(
                variables=self.macro_variables,
                rules=self.macro_rules,
                **sub_result[0]
            )
            
            result = result[0]['decision']
            if result > 8.0:
                segmentacion["100"].append(next(nombre))#,result))#,sub_result))
            elif 7.0 < result < 8.0:
                segmentacion["90"].append(next(nombre))#,result))#,sub_result))
            elif 6.0 < result < 7.0:
                segmentacion["80"].append(next(nombre))#,result))#,sub_result))
            elif 5.0 < result < 6.0:
                segmentacion["65"].append(next(nombre))#result))#,sub_result))
            elif 4.0 < result < 5.0:
                segmentacion["50"].append(next(nombre))#result))#,sub_result))
            elif 3.0 < result < 4.0:
                segmentacion["35"].append(next(nombre))#result))#,sub_result))
            elif 2.0 < result < 3.0:
                segmentacion["25"].append(next(nombre))#result))#,sub_result))
            elif 1.0 < result < 2.0:
                segmentacion["10"].append(next(nombre))#result))#,sub_result))
            elif 0.0 < result < 1.0:
                segmentacion["0"].append(next(nombre))#result))#,sub_result))
        return segmentacion
    

    def createRules(self,dataUsuario,prefix="OR"):
        usedValues = []
        premises = {}

        
        
        for etiqueta, categoria in dataUsuario:
            if categoria not in usedValues:
                usedValues.append(categoria)
                premises[categoria] = [(etiqueta,f"si_{etiqueta}")] 

            else:
                if isinstance(prefix,dict):
                    premises[categoria].append((prefix[categoria],etiqueta,f"si_{etiqueta}"))
                elif isinstance(prefix,str):
                    premises[categoria].append((prefix,etiqueta,f"si_{etiqueta}"))
                else:
                    raise ValueError("prefix only accept str and list type")
        return premises
    
    def reglas(self,premisas,consecuencia):
        reglas = []
        for keys,value in premisas.items():
            reglas.append(
                FuzzyRule(
                premise=value,
                consequence=[(consecuencia, keys)],
            )
            )
        return reglas

        
if __name__ == '__main__':
    window = Tk()
    application = Aplicacion(window)
    window.mainloop()
